import TimelineItem from '../timeline/timeline-item.vue';

export default TimelineItem;