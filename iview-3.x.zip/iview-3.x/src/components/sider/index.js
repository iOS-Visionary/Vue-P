import Sider from '../layout/sider.vue';

export default Sider; 