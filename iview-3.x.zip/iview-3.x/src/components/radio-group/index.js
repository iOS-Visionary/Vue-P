import RadioGroup from '../radio/radio-group.vue';

export default RadioGroup;