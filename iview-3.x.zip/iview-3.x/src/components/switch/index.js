import Switch from './switch.vue';
export default Switch;