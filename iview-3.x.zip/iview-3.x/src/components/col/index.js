import Col from '../grid/col.vue';

export default Col;