export default {
  'de-DE': 'Oktober 2030',
  'en-US': 'October 2030',
  'es-ES': 'octubre 2030',
  'fr-FR': 'octobre 2030',
  'id-ID': 'Oktober 2030',
  'ja-JP': '2030年 10月',
  'ko-KR': '2030년 10월',
  'pt-BR': 'outubro de 2030',
  'pt-PT': 'outubro de 2030',
  'ru-RU': 'Октябрь 2030',
  'sv-SE': 'oktober 2030',
  'tr-TR': 'Ekim 2030',
  'vi-VN': 'Tháng 10/2030',
  'zh-CN': '2030年 10月',
  'zh-TW': '2030年 10月'
};
